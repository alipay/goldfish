import { setupPage } from '@goldfishjs/composition-api';

Page(setupPage(() => {
  return {};
}));
