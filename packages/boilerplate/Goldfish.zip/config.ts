import { IConfig } from '@goldfishjs/plugins';

const config: IConfig = {
};

export default config;
